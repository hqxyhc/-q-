create view hello as
  select `fr`.`dept`.`DNAME` AS `DNAME`, `fr`.`emp`.`JOB` AS `JOB`, `fr`.`emp`.`SALARY` AS `SALARY`
  from `fr`.`dept`
         join `fr`.`emp`
  where (`fr`.`dept`.`DEPTNO` = `fr`.`emp`.`DEPTNO`);

