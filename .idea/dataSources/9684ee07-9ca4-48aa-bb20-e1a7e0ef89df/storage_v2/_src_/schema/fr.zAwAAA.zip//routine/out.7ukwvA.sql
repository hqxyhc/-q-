create procedure `out`(IN a INT(10))
  BEGIN
	#Routine body goes here...
select a;
set a=10;
select a;
END;

