create procedure hh(IN a INT(10))
  BEGIN
	#Routine body goes here...
select a;
set a=555;
select a;
END;

