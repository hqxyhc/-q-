create procedure `update`(IN p INT(10))
  BEGIN
	#Routine body goes here...
	/* 定义一个整形变量 */
declare v1 int;

/* 将输入参数的值赋给变量 */
set v1 = p;

/* 执行插入操作 */
update dept  set DEPTNO = v1 where DEPTNO=40;
END;

