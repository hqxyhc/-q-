create procedure hel()
  BEGIN
	#utine body goes here...
	select * from dept;

END;

